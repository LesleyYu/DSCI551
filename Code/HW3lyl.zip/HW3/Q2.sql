-- Use the CINEMA database
USE CINEMA;

-- Drop existing tables if they exist
DROP TABLE IF EXISTS DirectedBy, ActIn, Directors, Actors, Movies;


-- Please create the tables as per the structure given.
-- Remember to consider appropriate data types and primary/foreign key constraints.

-- Movies(id, title, year, length, language)
CREATE TABLE Movies (
    id INT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    year INT NOT NULL,
    length INT NOT NULL CHECK (length > 0),
    language VARCHAR(100) NOT NULL
);



-- Actors(id, name, gender)
CREATE TABLE Actors (
    id INT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    gender ENUM('Male', 'Female', 'Non-Binary', 'Other') NOT NULL
);



-- ActIn(actor_id, movie_id)
CREATE TABLE ActIn (
    actor_id INT,
    movie_id INT,
    PRIMARY KEY (actor_id, movie_id),
    FOREIGN KEY (actor_id) REFERENCES Actors(id),
    FOREIGN KEY (movie_id) REFERENCES Movies(id)
);


-- Directors(id, name, nationality)
CREATE TABLE Directors (
    id INT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    nationality VARCHAR(100) NOT NULL
);


-- DirectedBy(movie_id, director_id)
CREATE TABLE DirectedBy (
    movie_id INT,
    director_id INT,
    PRIMARY KEY (movie_id, director_id),
    FOREIGN KEY (movie_id) REFERENCES Movies(id),
    FOREIGN KEY (director_id) REFERENCES Directors(id)
);




-- Please insert sample data into the tables created above.
-- Note: Testing will be conducted on a blind test set, so ensure your table creation and data insertion scripts are accurate and comprehensive.


-- Movies
INSERT INTO Movies (id, title, year, length, language) VALUES
(1, 'The Shawshank Redemption', 1994, 175, 'en'),
(2, 'Parasite', 2019, 132, 'Korean'),
(3, 'Inception', 2010, 148, 'en'),
(4, 'Spirited Away', 2001, 125, 'Japanese'),
(5, 'Interstellar', 2014, 169, 'en'),
(6, 'Twilight', 2008, 122, 'en'),
(7, 'The Twilight Saga: Eclipse', 2010, 124, 'en'),
(8, 'A French Movie', 2020, 110, 'fr'),
(9, 'An English Movie', 2021, 105, 'en');


-- Actors
INSERT INTO Actors (id, name, gender) VALUES
(1, 'Morgan Freeman', 'Male'),
(2, 'Leonardo DiCaprio', 'Male'),
(3, 'Tom Hanks', 'Male'),
(4, 'Cho Yeo-jeong', 'Female'),
(5, 'Song Kang-ho', 'Male'),
(6, 'Rumi Hiiragi', 'Female'),
(7, 'Matthew McConaughey', 'Male'),
(8, 'Kristen Stewart', 'Female'),
(9, 'Robert Pattinson', 'Male'),
(10, 'Actor In Both', 'Male'); -- both


-- Directors
INSERT INTO Directors (id, name, nationality) VALUES
(1, 'Frank Darabont', 'American'),
(2, 'Bong Joon-ho', 'South Korean'),
(3, 'Christopher Nolan', 'British'),
(4, 'Hayao Miyazaki', 'Japanese'),
(5, 'Quentin Tarantino', 'American'),
(6, 'Steven Spielberg', 'American');


-- ActIn
INSERT INTO ActIn (actor_id, movie_id) VALUES
(1, 1),
(2, 3),
(3, 6), -- Tom Hanks act in "Twilight" 
(8, 6),
(8, 7),
(9, 6),
(10, 8),
(10, 9);


-- DirectedBy
INSERT INTO DirectedBy (movie_id, director_id) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 3),
(6, 6), -- Steven Spielberg direct Twilight
(7, 6), -- Steven Spielberg direct The Twilight Saga: Eclipse
(8, 5),
(9, 5);
