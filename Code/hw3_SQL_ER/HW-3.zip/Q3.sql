USE CINEMA;

-- 1) Find titles of the longest movies. Note that there might be more than such movie.


-- 2) Find out titles of movies that contain "Twilight" and are directed by "Steven Spielberg".


-- 3) Find out how many movies "Tom Hanks" has acted in.


-- 4) Find out which director directed only a single movie.


-- 5) Find titles of movies which have the largest number of actors. Note that there may be multiple such movies.


-- 6) Find names of actors who played in both English (language = "en") and French ("fr") movies.


-- 7) Find names of directors who only directed English movies.